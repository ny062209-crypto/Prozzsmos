package com.kira.autopost.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.kira.autopost.KiraApp
import com.kira.autopost.MainActivity
import com.kira.autopost.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class AutoPostForegroundService : Service() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private var simulationJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopAutoPost()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, createNotification("សេវាកម្មកំពុងដំណើរការ..."))
        KiraApp.instance.repository.setAutoPostRunning(true)

        // Launch monitoring loop
        startMonitoringLoop()

        return START_STICKY
    }

    private fun startMonitoringLoop() {
        simulationJob?.cancel()
        simulationJob = serviceScope.launch {
            // Periodically check selected groups and update notification stats
            while (isActive) {
                val reports = KiraApp.instance.repository.reports.value
                val successCount = reports.count { it.status == com.kira.autopost.data.model.ReportLog.ResultStatus.SUCCESS }
                val failedCount = reports.count { it.status == com.kira.autopost.data.model.ReportLog.ResultStatus.FAILED }
                val groupsCount = KiraApp.instance.repository.groups.value.count { it.isSelected }

                val text = "ក្រុមសកម្ម: $groupsCount | ជោគជ័យ: $successCount | បរាជ័យ: $failedCount"
                val notification = createNotification(text)
                val manager = getSystemService(NotificationManager::class.java)
                manager?.notify(NOTIFICATION_ID, notification)

                delay(15_000L)
            }
        }
    }

    private fun stopAutoPost() {
        KiraApp.instance.repository.setAutoPostRunning(false)
        simulationJob?.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotification(contentText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, AutoPostForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, KiraApp.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_kira_logo)
            .setContentTitle(getString(R.string.service_running_title))
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(contentText))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_media_pause,
                getString(R.string.home_btn_stop),
                stopPendingIntent
            )
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        KiraApp.instance.repository.setAutoPostRunning(false)
    }

    companion object {
        const val NOTIFICATION_ID = 2024
        const val ACTION_START = "com.kira.autopost.ACTION_START"
        const val ACTION_STOP = "com.kira.autopost.ACTION_STOP"

        fun start(context: Context) {
            val intent = Intent(context, AutoPostForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, AutoPostForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
