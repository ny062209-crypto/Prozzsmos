package com.kira.autopost.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted

@Composable
fun AppTopBar(
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Logo from Image 1
        Image(
            painter = painterResource(id = R.drawable.ic_kira_logo),
            contentDescription = "KIRA Logo",
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.width(12.dp))

        // Titles matching Image 2
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = stringResource(id = R.string.app_name),
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = KiraTextMain
            )
            Text(
                text = stringResource(id = R.string.app_subtitle),
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                color = KiraTextMuted
            )
        }

        // Settings gear button (top right, matching Image 2)
        IconButton(onClick = onSettingsClick) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = KiraPrimaryBlue,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}
