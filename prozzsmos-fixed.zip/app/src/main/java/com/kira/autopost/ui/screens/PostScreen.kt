package com.kira.autopost.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.data.model.PostConfig
import com.kira.autopost.ui.theme.KiraCardBgLight
import com.kira.autopost.ui.theme.KiraCardStrokeLight
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSuccessGreen
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted
import com.kira.autopost.ui.theme.KiraTextSecondary

@Composable
fun PostScreen(
    currentConfig: PostConfig,
    onSaveConfig: (PostConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by remember(currentConfig) { mutableStateOf(currentConfig.text) }
    var linksInput by remember(currentConfig) { mutableStateOf(currentConfig.links.joinToString("\n")) }
    var mentionUser by remember(currentConfig) { mutableStateOf(currentConfig.mentionUsername) }
    var mediaUriInput by remember(currentConfig) { mutableStateOf(currentConfig.mediaUri ?: "") }
    var showSavedBanner by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    val previewConfig = PostConfig(
        text = textInput,
        mediaUri = mediaUriInput.ifBlank { null },
        links = linksInput.split("\n").map { it.trim() }.filter { it.isNotBlank() },
        mentionUsername = mentionUser
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        Column {
            Text(
                text = stringResource(id = R.string.post_title),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = KiraTextMain
            )
            Text(
                text = stringResource(id = R.string.post_subtitle),
                fontSize = 12.sp,
                color = KiraTextMuted
            )
        }

        // Mention Username Checkbox (exact requirement: @username on the first line above text)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KiraCardBgLight),
            border = BorderStroke(1.dp, KiraCardStrokeLight)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = mentionUser,
                    onCheckedChange = { mentionUser = it },
                    colors = CheckboxDefaults.colors(checkedColor = KiraPrimaryBlue)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Mention Username (@username)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                    Text(
                        text = "ដាក់ @username របស់សមាជិកថ្មីនៅជួរទីមួយខាងលើអត្ថបទឆ្លើយតប",
                        fontSize = 12.sp,
                        color = KiraTextSecondary
                    )
                }
            }
        }

        // Text Box
        Column {
            Text(
                text = stringResource(id = R.string.post_text_label),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = KiraTextMain
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = RoundedCornerShape(14.dp),
                placeholder = { Text(stringResource(id = R.string.post_text_placeholder), fontSize = 13.sp) }
            )
        }

        // Media Input (Photo / Video)
        Column {
            Text(
                text = stringResource(id = R.string.post_media_label),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = KiraTextMain
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = mediaUriInput,
                onValueChange = { mediaUriInput = it },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = KiraPrimaryBlue)
                },
                placeholder = { Text(stringResource(id = R.string.post_media_hint), fontSize = 13.sp) },
                singleLine = true
            )
        }

        // Multiple Links Box
        Column {
            Text(
                text = stringResource(id = R.string.post_links_label),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = KiraTextMain
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = linksInput,
                onValueChange = { linksInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                shape = RoundedCornerShape(14.dp),
                placeholder = { Text(stringResource(id = R.string.post_links_placeholder), fontSize = 13.sp) }
            )
        }

        // Save Button
        Button(
            onClick = {
                onSaveConfig(previewConfig)
                showSavedBanner = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = KiraPrimaryBlue)
        ) {
            Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(id = R.string.post_btn_save),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Success Confirmation
        if (showSavedBanner) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFDCFCE7), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = KiraSuccessGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(id = R.string.post_saved_success),
                    fontSize = 13.sp,
                    color = Color(0xFF166534),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Show Saved Message Live Preview Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(id = R.string.post_preview_title),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = KiraPrimaryBlue
                )
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = previewConfig.getFormattedMessage("new_member_khmer"),
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = KiraTextMain
                    )
                }
            }
        }
    }
}
