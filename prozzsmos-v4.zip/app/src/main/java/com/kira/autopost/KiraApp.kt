package com.kira.autopost

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.kira.autopost.data.repository.AppPreferencesRepository
import com.kira.autopost.data.tdlib.TdlibManager

class KiraApp : Application() {

    lateinit var repository: AppPreferencesRepository
        private set

    lateinit var tdlibManager: TdlibManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        repository = AppPreferencesRepository(this)
        tdlibManager = TdlibManager(this, repository)

        createNotificationChannels()
        tdlibManager.restoreSession()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.service_channel_desc)
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "kira_autopost_foreground_channel"
        lateinit var instance: KiraApp
            private set
    }
}
