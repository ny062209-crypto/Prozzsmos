package com.kira.autopost.data.model

data class TelegramAccount(
    val id: Long,
    val phoneNumber: String,
    val apiId: String,
    val apiHash: String,
    val firstName: String = "",
    val lastName: String = "",
    val username: String = "",
    val isLoggedIn: Boolean = false,
    val sessionDirName: String = "session_$id"
)
