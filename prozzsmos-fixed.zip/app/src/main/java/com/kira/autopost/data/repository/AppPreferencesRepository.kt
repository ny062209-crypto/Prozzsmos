package com.kira.autopost.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.kira.autopost.data.model.AppSettings
import com.kira.autopost.data.model.PostConfig
import com.kira.autopost.data.model.ReportLog
import com.kira.autopost.data.model.TelegramAccount
import com.kira.autopost.data.model.TelegramGroup
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppPreferencesRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("kira_auto_post_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _accounts = MutableStateFlow<List<TelegramAccount>>(loadAccounts())
    val accounts: StateFlow<List<TelegramAccount>> = _accounts.asStateFlow()

    private val _groups = MutableStateFlow<List<TelegramGroup>>(loadGroups())
    val groups: StateFlow<List<TelegramGroup>> = _groups.asStateFlow()

    private val _postConfig = MutableStateFlow<PostConfig>(loadPostConfig())
    val postConfig: StateFlow<PostConfig> = _postConfig.asStateFlow()

    private val _reports = MutableStateFlow<List<ReportLog>>(loadReports())
    val reports: StateFlow<List<ReportLog>> = _reports.asStateFlow()

    private val _settings = MutableStateFlow<AppSettings>(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    // --- Accounts ---
    private fun loadAccounts(): List<TelegramAccount> {
        val json = prefs.getString(KEY_ACCOUNTS, null)
        if (json != null) {
            val type = object : TypeToken<List<TelegramAccount>>() {}.type
            return gson.fromJson(json, type) ?: defaultAccounts()
        }
        return defaultAccounts()
    }

    private fun defaultAccounts(): List<TelegramAccount> {
        return listOf(
            TelegramAccount(
                id = 1001L,
                phoneNumber = "+85598765432",
                apiId = "",
                apiHash = "",
                firstName = "KIRA",
                lastName = "Gaming",
                username = "kiragaming_official",
                isLoggedIn = true
            )
        )
    }

    fun saveAccounts(list: List<TelegramAccount>) {
        prefs.edit().putString(KEY_ACCOUNTS, gson.toJson(list)).apply()
        _accounts.value = list
    }

    fun addOrUpdateAccount(account: TelegramAccount) {
        val current = _accounts.value.toMutableList()
        val index = current.indexOfFirst { it.id == account.id }
        if (index >= 0) {
            current[index] = account
        } else {
            current.add(account)
        }
        saveAccounts(current)
    }

    fun removeAccount(accountId: Long) {
        val current = _accounts.value.filter { it.id != accountId }
        saveAccounts(current)
    }

    // --- Groups ---
    private fun loadGroups(): List<TelegramGroup> {
        val json = prefs.getString(KEY_GROUPS, null)
        if (json != null) {
            val type = object : TypeToken<List<TelegramGroup>>() {}.type
            return gson.fromJson(json, type) ?: defaultGroups()
        }
        return defaultGroups()
    }

    private fun defaultGroups(): List<TelegramGroup> {
        return listOf(
            TelegramGroup(
                id = -1001928374650L,
                title = "KIRA Gaming Official Community",
                memberCount = 12450,
                isSelected = true
            ),
            TelegramGroup(
                id = -1001837465920L,
                title = "Khmer Gamers & Streamers Hub",
                memberCount = 8920,
                isSelected = false
            ),
            TelegramGroup(
                id = -1001748291030L,
                title = "Telegram Cambodia Discussion",
                memberCount = 5640,
                isSelected = false
            )
        )
    }

    fun saveGroups(list: List<TelegramGroup>) {
        prefs.edit().putString(KEY_GROUPS, gson.toJson(list)).apply()
        _groups.value = list
    }

    fun toggleGroupSelection(groupId: Long) {
        val updated = _groups.value.map {
            if (it.id == groupId) it.copy(isSelected = !it.isSelected) else it
        }
        saveGroups(updated)
    }

    fun selectAllGroups(selected: Boolean) {
        val updated = _groups.value.map { it.copy(isSelected = selected) }
        saveGroups(updated)
    }

    // --- Post Config ---
    private fun loadPostConfig(): PostConfig {
        val json = prefs.getString(KEY_POST_CONFIG, null)
        if (json != null) {
            return gson.fromJson(json, PostConfig::class.java) ?: PostConfig()
        }
        return PostConfig()
    }

    fun savePostConfig(config: PostConfig) {
        prefs.edit().putString(KEY_POST_CONFIG, gson.toJson(config)).apply()
        _postConfig.value = config
    }

    // --- Reports ---
    private fun loadReports(): List<ReportLog> {
        val json = prefs.getString(KEY_REPORTS, null)
        if (json != null) {
            val type = object : TypeToken<List<ReportLog>>() {}.type
            return gson.fromJson(json, type) ?: defaultReports()
        }
        return defaultReports()
    }

    private fun defaultReports(): List<ReportLog> {
        return listOf(
            ReportLog(
                id = "rep_init_1",
                timestampMillis = System.currentTimeMillis() - 120_000,
                groupTitle = "KIRA Gaming Official Community",
                groupId = -1001928374650L,
                userIdentifier = "@sok_gamer",
                status = ReportLog.ResultStatus.SUCCESS,
                messageSnippet = "@sok_gamer សូមស្វាគមន៍មកកាន់ក្រុមរបស់យើង!..."
            )
        )
    }

    fun addReport(report: ReportLog) {
        val current = _reports.value.toMutableList()
        current.add(0, report) // add to top
        if (current.size > 200) current.removeAt(current.lastIndex)
        prefs.edit().putString(KEY_REPORTS, gson.toJson(current)).apply()
        _reports.value = current
    }

    fun clearReports() {
        prefs.edit().remove(KEY_REPORTS).apply()
        _reports.value = emptyList()
    }

    // --- Settings ---
    private fun loadSettings(): AppSettings {
        val json = prefs.getString(KEY_SETTINGS, null)
        if (json != null) {
            return gson.fromJson(json, AppSettings::class.java) ?: AppSettings()
        }
        return AppSettings()
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit().putString(KEY_SETTINGS, gson.toJson(settings)).apply()
        _settings.value = settings
    }

    fun setAutoPostRunning(isRunning: Boolean) {
        val updated = _settings.value.copy(isAutoPostRunning = isRunning)
        saveSettings(updated)
    }

    companion object {
        private const val KEY_ACCOUNTS = "key_telegram_accounts"
        private const val KEY_GROUPS = "key_telegram_groups"
        private const val KEY_POST_CONFIG = "key_post_config"
        private const val KEY_REPORTS = "key_reports"
        private const val KEY_SETTINGS = "key_settings"
    }
}
