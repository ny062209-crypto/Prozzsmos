package com.kira.autopost.data.model

data class AppSettings(
    val delaySeconds: Int = 0,
    val randomJitterSeconds: Int = 0,
    val isAutoPostRunning: Boolean = false
)
