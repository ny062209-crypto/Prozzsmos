package com.kira.autopost.data.model

data class PostConfig(
    val text: String = "សូមស្វាគមន៍មកកាន់ក្រុមរបស់យើង! សូមពិនិត្យព័ត៌មានខាងក្រោម:",
    val mediaUri: String? = null,
    val mediaType: MediaType = MediaType.NONE,
    val links: List<String> = listOf("https://t.me/KIRAGaming", "https://t.me/KIRACommunity"),
    val mentionUsername: Boolean = true
) {
    enum class MediaType {
        NONE, PHOTO, VIDEO
    }

    fun getFormattedMessage(username: String?): String {
        val sb = StringBuilder()
        if (mentionUsername && !username.isNullOrBlank()) {
            val cleanUser = if (username.startsWith("@")) username else "@$username"
            sb.append(cleanUser).append("\n\n")
        }
        sb.append(text)
        if (links.isNotEmpty()) {
            sb.append("\n\n")
            links.filter { it.isNotBlank() }.forEach { link ->
                sb.append("👉 ").append(link.trim()).append("\n")
            }
        }
        return sb.toString().trim()
    }
}
