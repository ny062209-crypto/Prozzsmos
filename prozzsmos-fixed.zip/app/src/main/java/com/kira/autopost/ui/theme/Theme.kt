package com.kira.autopost.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = KiraPrimaryBlue,
    onPrimary = KiraSurfaceWhite,
    primaryContainer = KiraCardBgLight,
    onPrimaryContainer = KiraPrimaryBlue,
    background = KiraBackgroundWhite,
    onBackground = KiraTextMain,
    surface = KiraSurfaceWhite,
    onSurface = KiraTextMain
)

@Composable
fun KIRAAutoPostTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
