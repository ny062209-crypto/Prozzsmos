package com.kira.autopost.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.ui.theme.KiraCardBgLight
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMuted

enum class AppTab(val titleResId: Int, val icon: ImageVector) {
    HOME(R.string.nav_home, Icons.Default.Home),
    ACCOUNTS(R.string.nav_accounts, Icons.Default.Person),
    GROUPS(R.string.nav_groups, Icons.Default.Groups),
    POST(R.string.nav_post, Icons.Default.Send),
    REPORTS(R.string.nav_reports, Icons.Default.BarChart),
    SETTINGS(R.string.nav_settings, Icons.Default.Settings)
}

@Composable
fun BottomNavBar(
    currentTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.fillMaxWidth(),
        containerColor = KiraSurfaceWhite,
        tonalElevation = 6.dp
    ) {
        AppTab.values().forEach { tab ->
            val isSelected = currentTab == tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = stringResource(id = tab.titleResId),
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = stringResource(id = tab.titleResId),
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = KiraPrimaryBlue,
                    selectedTextColor = KiraPrimaryBlue,
                    indicatorColor = KiraCardBgLight,
                    unselectedIconColor = KiraTextMuted,
                    unselectedTextColor = KiraTextMuted
                )
            )
        }
    }
}
