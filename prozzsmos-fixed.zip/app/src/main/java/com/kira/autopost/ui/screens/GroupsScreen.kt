package com.kira.autopost.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.data.model.TelegramGroup
import com.kira.autopost.ui.theme.KiraCardBgLight
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted
import com.kira.autopost.ui.theme.KiraTextSecondary

@Composable
fun GroupsScreen(
    groups: List<TelegramGroup>,
    onToggleGroup: (Long) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onSyncGroups: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredGroups = groups.filter {
        it.title.contains(searchQuery, ignoreCase = true)
    }

    val allSelected = groups.isNotEmpty() && groups.all { it.isSelected }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = stringResource(id = R.string.groups_title),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = KiraTextMain
                )
                Text(
                    text = stringResource(id = R.string.groups_subtitle),
                    fontSize = 12.sp,
                    color = KiraTextMuted
                )
            }

            OutlinedButton(
                onClick = onSyncGroups,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, KiraPrimaryBlue),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = KiraPrimaryBlue)
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "ទាញយក", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(stringResource(id = R.string.groups_search_hint), fontSize = 13.sp) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = KiraTextMuted)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Select All / Count Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "បានជ្រើស: ${groups.count { it.isSelected }} / ${groups.size} ក្រុម",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = KiraPrimaryBlue
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onSelectAll(!allSelected) }
            ) {
                Text(
                    text = if (allSelected) "ដោះទាំងអស់" else "ជ្រើសទាំងអស់",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = KiraTextSecondary
                )
                Checkbox(
                    checked = allSelected,
                    onCheckedChange = { onSelectAll(it) },
                    colors = CheckboxDefaults.colors(checkedColor = KiraPrimaryBlue)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Groups List
        if (filteredGroups.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(id = R.string.groups_no_groups),
                    fontSize = 13.sp,
                    color = KiraTextMuted
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredGroups, key = { it.id }) { group ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleGroup(group.id) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (group.isSelected) KiraCardBgLight else KiraSurfaceWhite
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (group.isSelected) KiraPrimaryBlue else Color(0xFFE2E8F0)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Avatar Logo
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(KiraPrimaryBlue.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = KiraPrimaryBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = group.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = KiraTextMain
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${group.memberCount} សមាជិក",
                                    fontSize = 12.sp,
                                    color = KiraTextMuted
                                )
                            }

                            Checkbox(
                                checked = group.isSelected,
                                onCheckedChange = { onToggleGroup(group.id) },
                                colors = CheckboxDefaults.colors(checkedColor = KiraPrimaryBlue)
                            )
                        }
                    }
                }
            }
        }
    }
}
