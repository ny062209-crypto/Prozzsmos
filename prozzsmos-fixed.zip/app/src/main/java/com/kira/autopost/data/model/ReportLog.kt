package com.kira.autopost.data.model

data class ReportLog(
    val id: String,
    val timestampMillis: Long,
    val groupTitle: String,
    val groupId: Long,
    val userIdentifier: String,
    val status: ResultStatus,
    val messageSnippet: String,
    val errorMessage: String? = null
) {
    enum class ResultStatus {
        SUCCESS,
        FAILED,
        FLOOD_WAIT
    }
}
