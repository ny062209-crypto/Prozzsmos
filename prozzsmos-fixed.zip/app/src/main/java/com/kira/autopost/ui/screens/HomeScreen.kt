package com.kira.autopost.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.data.model.ReportLog
import com.kira.autopost.ui.theme.KiraCardBgLight
import com.kira.autopost.ui.theme.KiraCardStrokeLight
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted
import com.kira.autopost.ui.theme.KiraTextSecondary

@Composable
fun HomeScreen(
    accountCount: Int,
    selectedGroupCount: Int,
    reports: List<ReportLog>,
    isAutoPostRunning: Boolean,
    onToggleAutoPost: () -> Unit,
    onNavigateToAccounts: () -> Unit,
    onNavigateToReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val successCount = reports.count { it.status == ReportLog.ResultStatus.SUCCESS }
    val failedCount = reports.count { it.status == ReportLog.ResultStatus.FAILED }
    val floodWaitCount = reports.count { it.status == ReportLog.ResultStatus.FLOOD_WAIT }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // --- 1. Safe Sending Card (Exact match to Image 2) ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = KiraCardBgLight),
            border = BorderStroke(1.dp, KiraCardStrokeLight)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Blue circle shield icon
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(KiraPrimaryBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Safe Sending",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = stringResource(id = R.string.home_safe_sending_title),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(id = R.string.home_safe_sending_desc),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = KiraTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- 2. Summary Section (Exact match to Image 2) ---
        Text(
            text = stringResource(id = R.string.home_summary_title),
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = KiraTextMain
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Accounts Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = KiraPrimaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(id = R.string.home_accounts_label),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = KiraTextMain
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = accountCount.toString(),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = stringResource(id = R.string.home_accounts_connected),
                        fontSize = 12.sp,
                        color = KiraTextMuted
                    )
                }
            }

            // Groups Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = null,
                            tint = KiraPrimaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(id = R.string.home_groups_label),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = KiraTextMain
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = selectedGroupCount.toString(),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = stringResource(id = R.string.home_groups_ready),
                        fontSize = 12.sp,
                        color = KiraTextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- 3. Results Card (Exact match to Image 2) ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(id = R.string.home_results_title),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                    Text(
                        text = stringResource(id = R.string.home_view_reports),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = KiraPrimaryBlue,
                        modifier = Modifier.clickable { onNavigateToReports() }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    // Success
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = successCount.toString(),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = KiraTextMain
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(id = R.string.home_result_success),
                            fontSize = 12.sp,
                            color = KiraTextSecondary
                        )
                    }

                    // Failed
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = failedCount.toString(),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = KiraTextMain
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(id = R.string.home_result_failed),
                            fontSize = 12.sp,
                            color = KiraTextSecondary
                        )
                    }

                    // Skipped / Flood-wait (represented with a subtle circle outline)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = floodWaitCount.toString(),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = KiraTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(id = R.string.home_result_skipped),
                            fontSize = 12.sp,
                            color = KiraTextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // --- 4. Quick Actions (Exact match to Image 2) ---
        Text(
            text = stringResource(id = R.string.home_quick_actions_title),
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = KiraTextMain
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Big Blue Button: Start / Stop Posting
        Button(
            onClick = onToggleAutoPost,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isAutoPostRunning) Color(0xFFDC2626) else KiraPrimaryBlue
            )
        ) {
            Icon(
                imageVector = if (isAutoPostRunning) Icons.Default.Pause else Icons.Default.Send,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = if (isAutoPostRunning) {
                    stringResource(id = R.string.home_btn_stop)
                } else {
                    stringResource(id = R.string.home_btn_start)
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Outlined Button: + Add New Telegram Account
        OutlinedButton(
            onClick = onNavigateToAccounts,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.5.dp, KiraPrimaryBlue),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = KiraPrimaryBlue)
        ) {
            Text(
                text = stringResource(id = R.string.home_btn_add_account),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = KiraPrimaryBlue
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
