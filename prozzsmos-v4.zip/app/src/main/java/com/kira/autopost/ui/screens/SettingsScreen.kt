package com.kira.autopost.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.data.model.AppSettings
import com.kira.autopost.ui.theme.KiraCardBgLight
import com.kira.autopost.ui.theme.KiraCardStrokeLight
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted
import com.kira.autopost.ui.theme.KiraTextSecondary

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSaveSettings: (AppSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        Column {
            Text(
                text = stringResource(id = R.string.settings_title),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = KiraTextMain
            )
            Text(
                text = "កំណត់សុវត្ថិភាព និង ការដំណើរការរបស់កម្មវិធី",
                fontSize = 12.sp,
                color = KiraTextMuted
            )
        }

        // Battery Optimization Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BatteryChargingFull,
                        contentDescription = null,
                        tint = KiraPrimaryBlue,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(id = R.string.settings_battery_label),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(id = R.string.settings_battery_desc),
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = KiraTextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            val intent = Intent(Settings.ACTION_SETTINGS)
                            context.startActivity(intent)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KiraCardBgLight)
                ) {
                    Text(
                        text = stringResource(id = R.string.settings_battery_btn),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraPrimaryBlue
                    )
                }
            }
        }

        // Notification Permission Card (Android 13+)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = KiraPrimaryBlue,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(id = R.string.settings_notification_label),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraTextMain
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(id = R.string.settings_notification_desc),
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = KiraTextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KiraCardBgLight)
                ) {
                    Text(
                        text = stringResource(id = R.string.settings_notification_btn),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = KiraPrimaryBlue
                    )
                }
            }
        }

        // About & Subtitle Credit
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = KiraCardBgLight),
            border = BorderStroke(1.dp, KiraCardStrokeLight)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "KIRA Auto Post v1.0.0",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = KiraPrimaryBlue
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stringResource(id = R.string.app_subtitle),
                    fontSize = 13.sp,
                    color = KiraTextSecondary
                )
            }
        }
    }
}
