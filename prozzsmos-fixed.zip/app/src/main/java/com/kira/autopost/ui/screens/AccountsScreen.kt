package com.kira.autopost.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.data.model.TelegramAccount
import com.kira.autopost.data.tdlib.TdlibManager
import com.kira.autopost.ui.theme.KiraCardBgLight
import com.kira.autopost.ui.theme.KiraCardStrokeLight
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSuccessGreen
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted
import com.kira.autopost.ui.theme.KiraTextSecondary

@Composable
fun AccountsScreen(
    accounts: List<TelegramAccount>,
    tdlibManager: TdlibManager,
    onRemoveAccount: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var apiIdInput by remember { mutableStateOf("") }
    var apiHashInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    var codeInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }

    val authStep by tdlibManager.authStep.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = stringResource(id = R.string.accounts_title),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = KiraTextMain
                )
                Text(
                    text = stringResource(id = R.string.accounts_subtitle),
                    fontSize = 12.sp,
                    color = KiraTextMuted
                )
            }

            Button(
                onClick = { showAddDialog = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = KiraPrimaryBlue)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "បន្ថែម", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (accounts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(id = R.string.accounts_no_accounts),
                    fontSize = 14.sp,
                    color = KiraTextMuted
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(accounts, key = { it.id }) { acc ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(KiraCardBgLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = KiraPrimaryBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (acc.firstName.isNotBlank()) "${acc.firstName} ${acc.lastName}".trim() else acc.phoneNumber,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = KiraTextMain
                                )
                                if (acc.username.isNotBlank()) {
                                    Text(
                                        text = "@${acc.username}",
                                        fontSize = 12.sp,
                                        color = KiraPrimaryBlue
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = KiraSuccessGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = stringResource(id = R.string.accounts_connected_status),
                                        fontSize = 11.sp,
                                        color = KiraSuccessGreen,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            IconButton(onClick = { onRemoveAccount(acc.id) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove Account",
                                    tint = Color(0xFFEF4444)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Login Dialog for TDLib User Account
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text(
                    text = stringResource(id = R.string.accounts_add_dialog_title),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    when (authStep) {
                        is TdlibManager.AuthStep.WaitingCode -> {
                            Text(
                                text = "បញ្ចូលលេខកូដ Telegram ដែលបានផ្ញើទៅកាន់លេខទូរស័ព្ទ:",
                                fontSize = 13.sp,
                                color = KiraTextSecondary
                            )
                            OutlinedTextField(
                                value = codeInput,
                                onValueChange = { codeInput = it },
                                label = { Text(stringResource(id = R.string.accounts_code)) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        is TdlibManager.AuthStep.WaitingPassword -> {
                            Text(
                                text = "គណនីមានភ្ជាប់ 2FA Password សូមបញ្ចូលពាក្យសម្ងាត់:",
                                fontSize = 13.sp,
                                color = KiraTextSecondary
                            )
                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text(stringResource(id = R.string.accounts_2fa)) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        is TdlibManager.AuthStep.Authenticated -> {
                            Text(
                                text = "ចូលគណនីបានជោគជ័យ! សម័យប្រជុំ (Session) ត្រូវបានរក្សាទុក។",
                                fontSize = 14.sp,
                                color = KiraSuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        else -> {
                            Text(
                                text = "បញ្ចូលព័ត៌មានពី my.telegram.org (គ្មាន token hardcode)",
                                fontSize = 12.sp,
                                color = KiraTextMuted
                            )
                            OutlinedTextField(
                                value = apiIdInput,
                                onValueChange = { apiIdInput = it },
                                label = { Text(stringResource(id = R.string.accounts_api_id)) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = apiHashInput,
                                onValueChange = { apiHashInput = it },
                                label = { Text(stringResource(id = R.string.accounts_api_hash)) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = phoneInput,
                                onValueChange = { phoneInput = it },
                                label = { Text(stringResource(id = R.string.accounts_phone)) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                }
            },
            confirmButton = {
                when (authStep) {
                    is TdlibManager.AuthStep.WaitingCode -> {
                        Button(
                            onClick = { tdlibManager.submitCode(codeInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = KiraPrimaryBlue)
                        ) {
                            Text(stringResource(id = R.string.accounts_btn_verify_code))
                        }
                    }
                    is TdlibManager.AuthStep.WaitingPassword -> {
                        Button(
                            onClick = { tdlibManager.submitPassword(passwordInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = KiraPrimaryBlue)
                        ) {
                            Text("ផ្ទៀងផ្ទាត់ 2FA")
                        }
                    }
                    is TdlibManager.AuthStep.Authenticated -> {
                        Button(
                            onClick = { showAddDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = KiraSuccessGreen)
                        ) {
                            Text("រួចរាល់")
                        }
                    }
                    else -> {
                        Button(
                            onClick = { tdlibManager.startLogin(apiIdInput, apiHashInput, phoneInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = KiraPrimaryBlue)
                        ) {
                            Text(stringResource(id = R.string.accounts_btn_send_code))
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("បោះបង់", color = KiraTextMuted)
                }
            }
        )
    }
}
