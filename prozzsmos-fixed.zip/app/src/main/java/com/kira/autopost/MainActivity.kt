package com.kira.autopost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.kira.autopost.service.AutoPostForegroundService
import com.kira.autopost.ui.components.AppTab
import com.kira.autopost.ui.components.AppTopBar
import com.kira.autopost.ui.components.BottomNavBar
import com.kira.autopost.ui.screens.AccountsScreen
import com.kira.autopost.ui.screens.GroupsScreen
import com.kira.autopost.ui.screens.HomeScreen
import com.kira.autopost.ui.screens.PostScreen
import com.kira.autopost.ui.screens.ReportsScreen
import com.kira.autopost.ui.screens.SettingsScreen
import com.kira.autopost.ui.theme.KIRAAutoPostTheme
import com.kira.autopost.ui.theme.KiraBackgroundWhite

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KIRAAutoPostTheme {
                MainAppContent(
                    onToggleAutoPost = { isCurrentlyRunning ->
                        if (isCurrentlyRunning) {
                            AutoPostForegroundService.stop(this)
                        } else {
                            AutoPostForegroundService.start(this)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun MainAppContent(
    onToggleAutoPost: (Boolean) -> Unit
) {
    val repository = KiraApp.instance.repository
    val tdlibManager = KiraApp.instance.tdlibManager

    val accounts by repository.accounts.collectAsState()
    val groups by repository.groups.collectAsState()
    val postConfig by repository.postConfig.collectAsState()
    val reports by repository.reports.collectAsState()
    val settings by repository.settings.collectAsState()

    var currentTab by remember { mutableStateOf(AppTab.HOME) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(KiraBackgroundWhite),
        topBar = {
            AppTopBar(
                onSettingsClick = { currentTab = AppTab.SETTINGS }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        }
    ) { paddingValues ->
        val contentModifier = Modifier.padding(paddingValues)

        when (currentTab) {
            AppTab.HOME -> {
                HomeScreen(
                    accountCount = accounts.size,
                    selectedGroupCount = groups.count { it.isSelected },
                    reports = reports,
                    isAutoPostRunning = settings.isAutoPostRunning,
                    onToggleAutoPost = {
                        onToggleAutoPost(settings.isAutoPostRunning)
                    },
                    onNavigateToAccounts = { currentTab = AppTab.ACCOUNTS },
                    onNavigateToReports = { currentTab = AppTab.REPORTS },
                    modifier = contentModifier
                )
            }
            AppTab.ACCOUNTS -> {
                AccountsScreen(
                    accounts = accounts,
                    tdlibManager = tdlibManager,
                    onRemoveAccount = { repository.removeAccount(it) },
                    modifier = contentModifier
                )
            }
            AppTab.GROUPS -> {
                GroupsScreen(
                    groups = groups,
                    onToggleGroup = { repository.toggleGroupSelection(it) },
                    onSelectAll = { repository.selectAllGroups(it) },
                    onSyncGroups = { tdlibManager.syncGroups() },
                    modifier = contentModifier
                )
            }
            AppTab.POST -> {
                PostScreen(
                    currentConfig = postConfig,
                    onSaveConfig = { repository.savePostConfig(it) },
                    modifier = contentModifier
                )
            }
            AppTab.REPORTS -> {
                ReportsScreen(
                    reports = reports,
                    onClearReports = { repository.clearReports() },
                    modifier = contentModifier
                )
            }
            AppTab.SETTINGS -> {
                SettingsScreen(
                    settings = settings,
                    onSaveSettings = { repository.saveSettings(it) },
                    modifier = contentModifier
                )
            }
        }
    }
}
