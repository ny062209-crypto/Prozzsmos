package com.kira.autopost.data.model

data class TelegramGroup(
    val id: Long,
    val title: String,
    val memberCount: Int,
    val photoUrl: String? = null,
    val isSelected: Boolean = true
)
