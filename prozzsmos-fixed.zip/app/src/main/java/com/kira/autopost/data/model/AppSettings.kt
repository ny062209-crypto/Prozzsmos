package com.kira.autopost.data.model

data class AppSettings(
    val delaySeconds: Int = 40,
    val randomJitterSeconds: Int = 5,
    val isAutoPostRunning: Boolean = false
)
