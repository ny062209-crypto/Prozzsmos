package com.kira.autopost.data.tdlib

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.kira.autopost.data.model.PostConfig
import com.kira.autopost.data.model.ReportLog
import com.kira.autopost.data.model.TelegramAccount
import com.kira.autopost.data.model.TelegramGroup
import com.kira.autopost.data.repository.AppPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import java.util.Collections
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

class TdlibManager(
    private val context: Context,
    private val repository: AppPreferencesRepository
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    private var activeClient: Client? = null
    private var myUserId: Long = 0L

    // Info of the session currently being created / restored
    private var pendingSessionDir: String = ""
    private var pendingApiId: String = ""
    private var pendingApiHash: String = ""

    sealed class AuthStep {
        object Idle : AuthStep()
        object WaitingParameters : AuthStep()
        object WaitingPhoneNumber : AuthStep()
        object WaitingCode : AuthStep()
        object WaitingPassword : AuthStep()
        data class Authenticated(val account: TelegramAccount) : AuthStep()
        data class Error(val message: String) : AuthStep()
    }

    private val _authStep = kotlinx.coroutines.flow.MutableStateFlow<AuthStep>(AuthStep.Idle)
    val authStep: kotlinx.coroutines.flow.StateFlow<AuthStep> = _authStep

    private val updateHandler = Client.ResultHandler { update ->
        when (update) {
            is TdApi.UpdateAuthorizationState -> handleAuthorizationState(update.authorizationState)
            is TdApi.UpdateNewMessage -> handleIncomingMessage(update.message)
            else -> Unit
        }
    }

    private val defaultResultHandler = Client.ResultHandler { result ->
        if (result is TdApi.Error) {
            Log.e("TdlibManager", "TDLib Error: ${result.code} - ${result.message}")
        }
    }

    // ---------------------------------------------------------------- Login

    fun startLogin(apiId: String, apiHash: String, phoneNumber: String) {
        val parsedApiId = apiId.trim().toIntOrNull() ?: 0
        if (parsedApiId <= 0 || apiHash.isBlank() || phoneNumber.isBlank()) {
            _authStep.value = AuthStep.Error("Please enter valid API ID, API Hash, and Phone Number.")
            return
        }
        val dirName = "tdlib_session_${System.currentTimeMillis()}"
        pendingSessionDir = dirName
        pendingApiId = apiId.trim()
        pendingApiHash = apiHash.trim()
        try {
            createClient(dirName, parsedApiId, apiHash.trim(), phoneNumber.trim())
        } catch (e: Throwable) {
            Log.e("TdlibManager", "Failed to start TDLib client", e)
            _authStep.value = AuthStep.Error("TDLib start failed: ${e.message}")
        }
    }

    /** Re-open the saved session after the app process restarts. */
    fun restoreSession() {
        if (activeClient != null) return
        val acc = repository.accounts.value.firstOrNull {
            it.isLoggedIn && it.apiId.toIntOrNull() != null && it.apiHash.isNotBlank() &&
                File(context.filesDir, it.sessionDirName).exists()
        } ?: return
        pendingSessionDir = acc.sessionDirName
        pendingApiId = acc.apiId
        pendingApiHash = acc.apiHash
        try {
            createClient(acc.sessionDirName, acc.apiId.toInt(), acc.apiHash, null)
        } catch (e: Throwable) {
            Log.e("TdlibManager", "Failed to restore session", e)
        }
    }

    private fun createClient(dirName: String, apiId: Int, apiHash: String, phone: String?) {
        activeClient?.send(TdApi.Close(), defaultResultHandler)
        val client = Client.create(
            updateHandler,
            { Log.e("TdlibManager", "TDLib update error", it) },
            { Log.e("TdlibManager", "TDLib default error", it) }
        )
        activeClient = client

        val sessionDir = File(context.filesDir, dirName)
        sessionDir.mkdirs()

        val parameters = TdApi.SetTdlibParameters().apply {
            this.databaseDirectory = sessionDir.absolutePath
            this.useMessageDatabase = true
            this.useSecretChats = false
            this.apiId = apiId
            this.apiHash = apiHash
            this.systemLanguageCode = "km"
            this.deviceModel = "Android"
            this.applicationVersion = "1.0.0"
            this.databaseEncryptionKey = ByteArray(0)
        }

        client.send(parameters) { result ->
            if (result is TdApi.Error) {
                mainHandler.post { _authStep.value = AuthStep.Error(result.message) }
            } else if (phone != null) {
                sendPhoneNumber(phone)
            }
        }
    }

    private fun sendPhoneNumber(phone: String) {
        activeClient?.send(TdApi.SetAuthenticationPhoneNumber(phone, TdApi.PhoneNumberAuthenticationSettings())) { result ->
            mainHandler.post {
                if (result is TdApi.Error) _authStep.value = AuthStep.Error(result.message)
            }
        }
    }

    fun submitCode(code: String) {
        val client = activeClient ?: run {
            _authStep.value = AuthStep.Error("Not connected. Please start login again.")
            return
        }
        client.send(TdApi.CheckAuthenticationCode(code.trim())) { result ->
            mainHandler.post {
                if (result is TdApi.Error) _authStep.value = AuthStep.Error(result.message)
            }
        }
    }

    fun submitPassword(password: String) {
        val client = activeClient ?: run {
            _authStep.value = AuthStep.Error("Not connected. Please start login again.")
            return
        }
        client.send(TdApi.CheckAuthenticationPassword(password)) { result ->
            mainHandler.post {
                if (result is TdApi.Error) _authStep.value = AuthStep.Error(result.message)
            }
        }
    }

    private fun handleAuthorizationState(state: TdApi.AuthorizationState) {
        mainHandler.post {
            when (state) {
                is TdApi.AuthorizationStateWaitTdlibParameters -> _authStep.value = AuthStep.WaitingParameters
                is TdApi.AuthorizationStateWaitPhoneNumber -> _authStep.value = AuthStep.WaitingPhoneNumber
                is TdApi.AuthorizationStateWaitCode -> _authStep.value = AuthStep.WaitingCode
                is TdApi.AuthorizationStateWaitPassword -> _authStep.value = AuthStep.WaitingPassword
                is TdApi.AuthorizationStateReady -> fetchMeAndSave()
                is TdApi.AuthorizationStateClosing,
                is TdApi.AuthorizationStateClosed -> _authStep.value = AuthStep.Idle
                else -> Unit
            }
        }
    }

    private fun fetchMeAndSave() {
        activeClient?.send(TdApi.GetMe()) { result ->
            if (result is TdApi.User) {
                myUserId = result.id
                val acc = TelegramAccount(
                    id = result.id,
                    phoneNumber = result.phoneNumber,
                    apiId = pendingApiId,
                    apiHash = pendingApiHash,
                    firstName = result.firstName,
                    lastName = result.lastName,
                    username = result.usernames?.activeUsernames?.firstOrNull() ?: "",
                    isLoggedIn = true,
                    sessionDirName = pendingSessionDir
                )
                repository.addOrUpdateAccount(acc)
                mainHandler.post { _authStep.value = AuthStep.Authenticated(acc) }
            }
        }
    }

    // ------------------------------------------------ Join detection + reply

    private fun handleIncomingMessage(message: TdApi.Message) {
        if (!repository.settings.value.isAutoPostRunning) return

        val joinedUserIds: List<Long> = when (val content = message.content) {
            is TdApi.MessageChatAddMembers -> content.memberUserIds.toList()
            is TdApi.MessageChatJoinByLink -> listOfNotNull((message.senderId as? TdApi.MessageSenderUser)?.userId)
            is TdApi.MessageChatJoinByRequest -> listOfNotNull((message.senderId as? TdApi.MessageSenderUser)?.userId)
            else -> return
        }

        val chatId = message.chatId
        val group = repository.groups.value.firstOrNull { it.isSelected && it.id == chatId } ?: return

        joinedUserIds.filter { it != myUserId }.forEach { userId ->
            replyToNewMember(chatId, group.title, message.id, userId)
        }
    }

    private fun replyToNewMember(chatId: Long, groupTitle: String, joinMessageId: Long, userId: Long) {
        val client = activeClient ?: return
        client.send(TdApi.GetUser(userId)) { userResult ->
            val user = userResult as? TdApi.User
            val username = user?.usernames?.activeUsernames?.firstOrNull() ?: ""
            val firstName = user?.firstName ?: ""
            scope.launch {
                sendReply(chatId, groupTitle, joinMessageId, userId, username, firstName, attempt = 0)
            }
        }
    }

    private fun buildFormattedText(
        config: PostConfig,
        userId: Long,
        username: String,
        firstName: String
    ): TdApi.FormattedText {
        val body = config.getFormattedMessage(null)
        if (!config.mentionUsername) return TdApi.FormattedText(body, arrayOf())

        return when {
            username.isNotBlank() -> {
                val mention = "@$username"
                val entity = TdApi.TextEntity(0, mention.length, TdApi.TextEntityTypeMention())
                TdApi.FormattedText(mention + "\n\n" + body, arrayOf(entity))
            }
            firstName.isNotBlank() -> {
                val entity = TdApi.TextEntity(0, firstName.length, TdApi.TextEntityTypeMentionName(userId))
                TdApi.FormattedText(firstName + "\n\n" + body, arrayOf(entity))
            }
            else -> TdApi.FormattedText(body, arrayOf())
        }
    }

    private fun copyUriToCache(uriString: String, type: PostConfig.MediaType): String? {
        return try {
            val uri = Uri.parse(uriString)
            val ext = if (type == PostConfig.MediaType.VIDEO) "mp4" else "jpg"
            val outFile = File(context.cacheDir, "post_media.$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                outFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            outFile.absolutePath
        } catch (e: Throwable) {
            Log.e("TdlibManager", "Cannot read media", e)
            null
        }
    }

    private fun buildReplyTo(joinMessageId: Long): TdApi.InputMessageReplyTo {
        return TdApi.InputMessageReplyToMessage().apply { this.messageId = joinMessageId }
    }

    private suspend fun sendReply(
        chatId: Long,
        groupTitle: String,
        joinMessageId: Long,
        userId: Long,
        username: String,
        firstName: String,
        attempt: Int
    ) {
        val client = activeClient ?: return
        val config = repository.postConfig.value
        val formatted = buildFormattedText(config, userId, username, firstName)
        val who = if (username.isNotBlank()) "@$username" else if (firstName.isNotBlank()) firstName else "User #$userId"

        val mediaPath = if (config.mediaType != PostConfig.MediaType.NONE && !config.mediaUri.isNullOrBlank()) {
            copyUriToCache(config.mediaUri, config.mediaType)
        } else null

        val captionFits = formatted.text.length <= 1000
        val content: TdApi.InputMessageContent = when {
            mediaPath != null && config.mediaType == PostConfig.MediaType.PHOTO ->
                TdApi.InputMessagePhoto().apply {
                    this.photo = TdApi.InputFileLocal(mediaPath)
                    if (captionFits) this.caption = formatted
                }
            mediaPath != null && config.mediaType == PostConfig.MediaType.VIDEO ->
                TdApi.InputMessageVideo().apply {
                    this.video = TdApi.InputFileLocal(mediaPath)
                    this.supportsStreaming = true
                    if (captionFits) this.caption = formatted
                }
            else -> TdApi.InputMessageText().apply { this.text = formatted }
        }

        val send = TdApi.SendMessage().apply {
            this.chatId = chatId
            this.replyTo = buildReplyTo(joinMessageId)
            this.inputMessageContent = content
        }

        client.send(send) { result ->
            when (result) {
                is TdApi.Message -> {
                    // Long text with media: send text as a separate follow-up reply
                    if (mediaPath != null && !captionFits) {
                        val textSend = TdApi.SendMessage().apply {
                            this.chatId = chatId
                            this.replyTo = buildReplyTo(joinMessageId)
                            this.inputMessageContent = TdApi.InputMessageText().apply { this.text = formatted }
                        }
                        client.send(textSend, defaultResultHandler)
                    }
                    addLog(chatId, groupTitle, who, ReportLog.ResultStatus.SUCCESS, formatted.text, null)
                }
                is TdApi.Error -> {
                    if (result.code == 429 || result.message.contains("FLOOD_WAIT", ignoreCase = true)) {
                        val waitSeconds = extractWaitSeconds(result.message)
                        addLog(
                            chatId, groupTitle, who, ReportLog.ResultStatus.FLOOD_WAIT,
                            "Flood-wait: ${waitSeconds}s", result.message
                        )
                        if (attempt < 3) {
                            scope.launch {
                                delay(waitSeconds * 1000L)
                                sendReply(chatId, groupTitle, joinMessageId, userId, username, firstName, attempt + 1)
                            }
                        }
                    } else {
                        addLog(chatId, groupTitle, who, ReportLog.ResultStatus.FAILED, formatted.text, result.message)
                    }
                }
                else -> Unit
            }
        }
    }

    private fun addLog(
        chatId: Long,
        groupTitle: String,
        who: String,
        status: ReportLog.ResultStatus,
        snippet: String,
        error: String?
    ) {
        repository.addReport(
            ReportLog(
                id = UUID.randomUUID().toString(),
                timestampMillis = System.currentTimeMillis(),
                groupTitle = groupTitle,
                groupId = chatId,
                userIdentifier = who,
                status = status,
                messageSnippet = snippet.take(100),
                errorMessage = error
            )
        )
    }

    private fun extractWaitSeconds(message: String): Long {
        return Regex("""\d+""").find(message)?.value?.toLongOrNull() ?: 60L
    }

    /**
     * Large supergroups only push live updates to chats that are "open".
     * Opening the selected chats makes sure join messages are delivered.
     */
    fun openSelectedChats() {
        val client = activeClient ?: return
        repository.groups.value.filter { it.isSelected }.forEach { g ->
            client.send(TdApi.OpenChat(g.id), defaultResultHandler)
        }
    }

    // ------------------------------------------------------- Group import

    fun syncGroups() {
        val client = activeClient ?: return
        client.send(TdApi.LoadChats(TdApi.ChatListMain(), 200)) {
            // LoadChats may return an error (404) when everything is already loaded; that is fine.
            client.send(TdApi.GetChats(TdApi.ChatListMain(), 200)) { result ->
                if (result !is TdApi.Chats) return@send
                val ids = result.chatIds
                if (ids.isEmpty()) return@send

                val previous = repository.groups.value.associate { it.id to it.isSelected }
                val collected = Collections.synchronizedList(mutableListOf<TelegramGroup>())
                val remaining = AtomicInteger(ids.size)

                fun finishOne() {
                    if (remaining.decrementAndGet() == 0) {
                        val list = synchronized(collected) { collected.toList() }
                        repository.saveGroups(list.sortedByDescending { it.memberCount })
                    }
                }

                ids.forEach { chatId ->
                    client.send(TdApi.GetChat(chatId)) { chatResult ->
                        if (chatResult !is TdApi.Chat) {
                            finishOne()
                            return@send
                        }
                        val chat = chatResult
                        val type = chat.type
                        val selected = previous[chat.id] ?: false

                        fun addGroup(count: Int) {
                            val photoFile = chat.photo?.small
                            if (photoFile != null) {
                                val dl = TdApi.DownloadFile().apply {
                                    this.fileId = photoFile.id
                                    this.priority = 1
                                    this.synchronous = true
                                }
                                client.send(dl) { fileResult ->
                                    val path = (fileResult as? TdApi.File)?.local?.path
                                    collected.add(
                                        TelegramGroup(chat.id, chat.title, count, path?.takeIf { it.isNotBlank() }, selected)
                                    )
                                    finishOne()
                                }
                            } else {
                                collected.add(TelegramGroup(chat.id, chat.title, count, null, selected))
                                finishOne()
                            }
                        }

                        when (type) {
                            is TdApi.ChatTypeSupergroup -> {
                                client.send(TdApi.GetSupergroup(type.supergroupId)) { sg ->
                                    addGroup((sg as? TdApi.Supergroup)?.memberCount ?: 0)
                                }
                            }
                            is TdApi.ChatTypeBasicGroup -> {
                                client.send(TdApi.GetBasicGroup(type.basicGroupId)) { bg ->
                                    addGroup((bg as? TdApi.BasicGroup)?.memberCount ?: 0)
                                }
                            }
                            else -> finishOne()
                        }
                    }
                }
            }
        }
    }
}
