package com.kira.autopost.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kira.autopost.R
import com.kira.autopost.data.model.ReportLog
import com.kira.autopost.ui.theme.KiraErrorRed
import com.kira.autopost.ui.theme.KiraPrimaryBlue
import com.kira.autopost.ui.theme.KiraSuccessGreen
import com.kira.autopost.ui.theme.KiraSurfaceWhite
import com.kira.autopost.ui.theme.KiraTextMain
import com.kira.autopost.ui.theme.KiraTextMuted
import com.kira.autopost.ui.theme.KiraTextSecondary
import com.kira.autopost.ui.theme.KiraWarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    reports: List<ReportLog>,
    onClearReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf<ReportLog.ResultStatus?>(null) }

    val filteredReports = reports.filter {
        selectedFilter == null || it.status == selectedFilter
    }

    val dateFormat = remember { SimpleDateFormat("HH:mm:ss - dd/MM/yyyy", Locale.getDefault()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = stringResource(id = R.string.reports_title),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = KiraTextMain
                )
                Text(
                    text = stringResource(id = R.string.reports_subtitle),
                    fontSize = 12.sp,
                    color = KiraTextMuted
                )
            }

            if (reports.isNotEmpty()) {
                OutlinedButton(
                    onClick = onClearReports,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, KiraErrorRed),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = KiraErrorRed)
                ) {
                    Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "សម្អាត", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Filter Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                null to "ទាំងអស់",
                ReportLog.ResultStatus.SUCCESS to "ជោគជ័យ",
                ReportLog.ResultStatus.FAILED to "បរាជ័យ",
                ReportLog.ResultStatus.FLOOD_WAIT to "រំលង"
            ).forEach { (status, label) ->
                val isSelected = selectedFilter == status
                Box(
                    modifier = Modifier
                        .background(
                            if (isSelected) KiraPrimaryBlue else Color(0xFFF1F5F9),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else KiraTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Reports List
        if (filteredReports.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(id = R.string.reports_empty),
                    fontSize = 14.sp,
                    color = KiraTextMuted
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredReports, key = { it.id }) { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = KiraSurfaceWhite),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = dateFormat.format(Date(log.timestampMillis)),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = KiraTextMuted
                                )

                                val (statusText, statusBg, statusColor) = when (log.status) {
                                    ReportLog.ResultStatus.SUCCESS -> Triple("ជោគជ័យ", Color(0xFFDCFCE7), KiraSuccessGreen)
                                    ReportLog.ResultStatus.FAILED -> Triple("បរាជ័យ", Color(0xFFFEE2E2), KiraErrorRed)
                                    ReportLog.ResultStatus.FLOOD_WAIT -> Triple("Flood Wait", Color(0xFFFEF3C7), KiraWarningAmber)
                                }

                                Box(
                                    modifier = Modifier
                                        .background(statusBg, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = statusText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "ក្រុម: ${log.groupTitle}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = KiraTextMain
                            )

                            Text(
                                text = "សមាជិក: ${log.userIdentifier}",
                                fontSize = 12.sp,
                                color = KiraPrimaryBlue
                            )

                            if (!log.errorMessage.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "កំហុស: ${log.errorMessage}",
                                    fontSize = 11.sp,
                                    color = KiraErrorRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
