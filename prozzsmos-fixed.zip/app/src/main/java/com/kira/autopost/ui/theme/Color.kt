package com.kira.autopost.ui.theme

import androidx.compose.ui.graphics.Color

val KiraPrimaryBlue = Color(0xFF1E78EB)
val KiraPrimaryBlueHover = Color(0xFF1562C7)
val KiraCardBgLight = Color(0xFFEBF3FF)
val KiraCardStrokeLight = Color(0xFFCCE0FD)
val KiraBackgroundWhite = Color(0xFFF8FAFC)
val KiraSurfaceWhite = Color(0xFFFFFFFF)
val KiraTextMain = Color(0xFF0F172A)
val KiraTextSecondary = Color(0xFF334155)
val KiraTextMuted = Color(0xFF64748B)

val KiraSuccessGreen = Color(0xFF10B981)
val KiraErrorRed = Color(0xFFEF4444)
val KiraWarningAmber = Color(0xFFF59E0B)
