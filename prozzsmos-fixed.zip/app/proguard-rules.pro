# Proguard rules for KIRA Auto Post & TDLib
-keep class org.drinkless.tdlib.** { *; }
-dontwarn org.drinkless.tdlib.**
-keep class com.kira.autopost.data.model.** { *; }
