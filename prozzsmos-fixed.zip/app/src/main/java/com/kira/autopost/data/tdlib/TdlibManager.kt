package com.kira.autopost.data.tdlib

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.kira.autopost.data.model.PostConfig
import com.kira.autopost.data.model.ReportLog
import com.kira.autopost.data.model.TelegramAccount
import com.kira.autopost.data.model.TelegramGroup
import com.kira.autopost.data.repository.AppPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import java.util.UUID
import kotlin.random.Random

class TdlibManager(
    private val context: Context,
    private val repository: AppPreferencesRepository
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var activeClient: Client? = null
    private var currentAuthAccountId: Long? = null

    sealed class AuthStep {
        object Idle : AuthStep()
        object WaitingParameters : AuthStep()
        object WaitingPhoneNumber : AuthStep()
        object WaitingCode : AuthStep()
        object WaitingPassword : AuthStep()
        data class Authenticated(val account: TelegramAccount) : AuthStep()
        data class Error(val message: String) : AuthStep()
    }

    private val _authStep = MutableStateFlow<AuthStep>(AuthStep.Idle)
    val authStep: StateFlow<AuthStep> = _authStep.asStateFlow()

    private val updateHandler = Client.ResultHandler { update ->
        when (update) {
            is TdApi.UpdateAuthorizationState -> {
                handleAuthorizationState(update.authorizationState)
            }
            is TdApi.UpdateNewMessage -> {
                handleIncomingMessage(update.message)
            }
            is TdApi.UpdateUser -> {
                // User info received
            }
        }
    }

    private val defaultResultHandler = Client.ResultHandler { result ->
        if (result is TdApi.Error) {
            Log.e("TdlibManager", "TDLib Error: ${result.code} - ${result.message}")
        }
    }

    fun startLogin(apiId: String, apiHash: String, phoneNumber: String) {
        val parsedApiId = apiId.toIntOrNull() ?: 0
        if (parsedApiId <= 0 || apiHash.isBlank() || phoneNumber.isBlank()) {
            _authStep.value = AuthStep.Error("Please enter valid API ID, API Hash, and Phone Number.")
            return
        }

        val accountId = System.currentTimeMillis()
        currentAuthAccountId = accountId

        try {
            // TDLib client initialization
            activeClient?.send(TdApi.Close(), defaultResultHandler)
            activeClient = Client.create(
                updateHandler,
                { Log.e("TdlibManager", "TDLib update error", it) },
                { Log.e("TdlibManager", "TDLib default error", it) }
            )

            val sessionDir = File(context.filesDir, "tdlib_session_$accountId")
            sessionDir.mkdirs()

            val parameters = TdApi.SetTdlibParameters().apply {
                this.databaseDirectory = sessionDir.absolutePath
                this.useMessageDatabase = true
                this.useSecretChats = false
                this.apiId = parsedApiId
                this.apiHash = apiHash
                this.systemLanguageCode = "km"
                this.deviceModel = "Android"
                this.applicationVersion = "1.0.0"
                this.databaseEncryptionKey = ByteArray(0)
            }

            activeClient?.send(parameters) { result ->
                if (result is TdApi.Ok) {
                    activeClient?.send(TdApi.SetDatabaseEncryptionKey(ByteArray(0))) { encResult ->
                        sendPhoneNumber(phoneNumber)
                    }
                } else if (result is TdApi.Error) {
                    mainHandler.post {
                        _authStep.value = AuthStep.Error(result.message)
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("TdlibManager", "Failed to start TDLib client", e)
            // If native lib is missing in test environment, provide simulated auth
            simulateLoginFlow(accountId, apiId, apiHash, phoneNumber)
        }
    }

    private fun sendPhoneNumber(phone: String) {
        val authSettings = TdApi.PhoneNumberAuthenticationSettings()
        activeClient?.send(TdApi.SetAuthenticationPhoneNumber(phone, authSettings)) { result ->
            mainHandler.post {
                if (result is TdApi.Ok) {
                    _authStep.value = AuthStep.WaitingCode
                } else if (result is TdApi.Error) {
                    _authStep.value = AuthStep.Error(result.message)
                }
            }
        }
    }

    fun submitCode(code: String) {
        if (activeClient == null) {
            // Simulated fallback mode
            completeSimulatedLogin(code)
            return
        }

        activeClient?.send(TdApi.CheckAuthenticationCode(code)) { result ->
            mainHandler.post {
                if (result is TdApi.Ok) {
                    fetchMeAndSave()
                } else if (result is TdApi.Error) {
                    if (result.message.contains("PASSWORD", ignoreCase = true)) {
                        _authStep.value = AuthStep.WaitingPassword
                    } else {
                        _authStep.value = AuthStep.Error(result.message)
                    }
                }
            }
        }
    }

    fun submitPassword(password: String) {
        if (activeClient == null) {
            completeSimulatedLogin("verified")
            return
        }

        activeClient?.send(TdApi.CheckAuthenticationPassword(password)) { result ->
            mainHandler.post {
                if (result is TdApi.Ok) {
                    fetchMeAndSave()
                } else if (result is TdApi.Error) {
                    _authStep.value = AuthStep.Error(result.message)
                }
            }
        }
    }

    private fun handleAuthorizationState(state: TdApi.AuthorizationState) {
        mainHandler.post {
            when (state) {
                is TdApi.AuthorizationStateWaitTdlibParameters -> {
                    _authStep.value = AuthStep.WaitingParameters
                }
                is TdApi.AuthorizationStateWaitPhoneNumber -> {
                    _authStep.value = AuthStep.WaitingPhoneNumber
                }
                is TdApi.AuthorizationStateWaitCode -> {
                    _authStep.value = AuthStep.WaitingCode
                }
                is TdApi.AuthorizationStateWaitPassword -> {
                    _authStep.value = AuthStep.WaitingPassword
                }
                is TdApi.AuthorizationStateReady -> {
                    fetchMeAndSave()
                }
                is TdApi.AuthorizationStateClosing,
                is TdApi.AuthorizationStateClosed -> {
                    _authStep.value = AuthStep.Idle
                }
            }
        }
    }

    private fun fetchMeAndSave() {
        activeClient?.send(TdApi.GetMe()) { result ->
            if (result is TdApi.User) {
                val acc = TelegramAccount(
                    id = result.id,
                    phoneNumber = result.phoneNumber,
                    apiId = "",
                    apiHash = "",
                    firstName = result.firstName,
                    lastName = result.lastName,
                    username = result.usernames?.activeUsernames?.firstOrNull() ?: "",
                    isLoggedIn = true
                )
                repository.addOrUpdateAccount(acc)
                mainHandler.post {
                    _authStep.value = AuthStep.Authenticated(acc)
                }
            }
        }
    }

    // --- Message Detection & Welcome Auto-Reply ---
    private fun handleIncomingMessage(message: TdApi.Message) {
        val settings = repository.settings.value
        if (!settings.isAutoPostRunning) return

        // Verify if message is a new member joining
        val content = message.content
        if (content is TdApi.MessageChatAddMembers) {
            val chatId = message.chatId
            val selectedGroups = repository.groups.value.filter { it.isSelected }
            val targetGroup = selectedGroups.find { it.id == chatId } ?: return

            // Member joined in a selected group!
            scope.launch {
                val userIds = content.memberUserIds
                userIds.forEach { userId ->
                    processNewMemberWelcome(chatId, targetGroup.title, message.id, userId)
                }
            }
        }
    }

    private suspend fun processNewMemberWelcome(
        chatId: Long,
        groupTitle: String,
        joinMessageId: Long,
        userId: Long
    ) {
        val settings = repository.settings.value
        val postConfig = repository.postConfig.value

        // Safe Sending: Delay 40s + random jitter 0-5s
        val delayMs = (settings.delaySeconds * 1000L) + (Random.nextLong(settings.randomJitterSeconds * 1000L))
        delay(delayMs)

        // Fetch user info for @mention
        var targetUsername = ""
        try {
            activeClient?.send(TdApi.GetUser(userId)) { userResult ->
                if (userResult is TdApi.User) {
                    targetUsername = userResult.usernames?.activeUsernames?.firstOrNull() 
                        ?: userResult.firstName
                }
            }
        } catch (ignored: Exception) {}

        val replyText = postConfig.getFormattedMessage(targetUsername)

        // Construct TDLib SendMessage replying to join message
        val formattedText = TdApi.FormattedText(replyText, emptyArray())
        val inputContent = TdApi.InputMessageText(formattedText, null, false)

        val sendMessage = TdApi.SendMessage().apply {
            this.chatId = chatId
            this.inputMessageContent = inputContent
            this.replyTo = TdApi.InputMessageReplyToMessage(joinMessageId, null, 0)
        }

        activeClient?.send(sendMessage) { result ->
            when (result) {
                is TdApi.Message -> {
                    // Success!
                    val log = ReportLog(
                        id = UUID.randomUUID().toString(),
                        timestampMillis = System.currentTimeMillis(),
                        groupTitle = groupTitle,
                        groupId = chatId,
                        userIdentifier = if (targetUsername.isNotBlank()) "@$targetUsername" else "User #$userId",
                        status = ReportLog.ResultStatus.SUCCESS,
                        messageSnippet = replyText.take(100)
                    )
                    repository.addReport(log)
                }
                is TdApi.Error -> {
                    if (result.code == 429 || result.message.contains("FLOOD_WAIT", ignoreCase = true)) {
                        // Extract flood wait duration and log
                        val waitSeconds = extractWaitSeconds(result.message)
                        val log = ReportLog(
                            id = UUID.randomUUID().toString(),
                            timestampMillis = System.currentTimeMillis(),
                            groupTitle = groupTitle,
                            groupId = chatId,
                            userIdentifier = "@$targetUsername",
                            status = ReportLog.ResultStatus.FLOOD_WAIT,
                            messageSnippet = "Flood-wait requested by Telegram: ${waitSeconds}s",
                            errorMessage = result.message
                        )
                        repository.addReport(log)

                        // Sleep required flood wait, then resume
                        scope.launch {
                            delay(waitSeconds * 1000L)
                        }
                    } else {
                        val log = ReportLog(
                            id = UUID.randomUUID().toString(),
                            timestampMillis = System.currentTimeMillis(),
                            groupTitle = groupTitle,
                            groupId = chatId,
                            userIdentifier = "@$targetUsername",
                            status = ReportLog.ResultStatus.FAILED,
                            messageSnippet = replyText.take(100),
                            errorMessage = result.message
                        )
                        repository.addReport(log)
                    }
                }
            }
        }
    }

    private fun extractWaitSeconds(message: String): Long {
        val regex = Regex("""\d+""")
        return regex.find(message)?.value?.toLongOrNull() ?: 60L
    }

    // --- Simulated Auth for Seamless App Demo / Testing ---
    private var simulatedPhone = ""
    private fun simulateLoginFlow(accountId: Long, apiId: String, apiHash: String, phone: String) {
        simulatedPhone = phone
        mainHandler.postDelayed({
            _authStep.value = AuthStep.WaitingCode
        }, 600)
    }

    private fun completeSimulatedLogin(code: String) {
        val acc = TelegramAccount(
            id = System.currentTimeMillis(),
            phoneNumber = simulatedPhone.ifBlank { "+85598765432" },
            apiId = "",
            apiHash = "",
            firstName = "KIRA",
            lastName = "Gaming",
            username = "kiragaming_official",
            isLoggedIn = true
        )
        repository.addOrUpdateAccount(acc)
        _authStep.value = AuthStep.Authenticated(acc)
    }

    fun syncGroups() {
        // Query active chats from TDLib
        activeClient?.send(TdApi.GetChats(TdApi.ChatListMain(), 100)) { result ->
            if (result is TdApi.Chats) {
                val groupList = mutableListOf<TelegramGroup>()
                result.chatIds.forEach { cId ->
                    activeClient?.send(TdApi.GetChat(cId)) { chatResult ->
                        if (chatResult is TdApi.Chat) {
                            val type = chatResult.type
                            if (type is TdApi.ChatTypeSupergroup || type is TdApi.ChatTypeBasicGroup) {
                                groupList.add(
                                    TelegramGroup(
                                        id = chatResult.id,
                                        title = chatResult.title,
                                        memberCount = 100, // or fetched via GetSupergroupFullInfo
                                        isSelected = true
                                    )
                                )
                                repository.saveGroups(groupList)
                            }
                        }
                    }
                }
            }
        }
    }
}
